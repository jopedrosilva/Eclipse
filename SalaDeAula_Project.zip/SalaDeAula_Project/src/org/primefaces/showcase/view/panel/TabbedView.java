package org.primefaces.showcase.view.panel;

import javax.faces.bean.ManagedBean;

@ManagedBean
public class TabbedView {

}
